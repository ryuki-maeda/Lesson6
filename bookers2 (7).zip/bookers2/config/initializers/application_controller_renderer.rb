# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '1e7dccdcfd030370c9c02bf864327bc1c9384ecd110ea6e2cc1379fffe52a31245634c9d932201f5c3ca788f855ab39f7d82b72ed38889ee8d2632447436e955'